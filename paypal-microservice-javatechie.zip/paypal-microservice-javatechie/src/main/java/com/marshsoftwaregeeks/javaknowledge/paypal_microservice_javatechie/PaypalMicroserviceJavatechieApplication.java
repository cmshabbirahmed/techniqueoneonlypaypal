package com.marshsoftwaregeeks.javaknowledge.paypal_microservice_javatechie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaypalMicroserviceJavatechieApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaypalMicroserviceJavatechieApplication.class, args);
	}

}
