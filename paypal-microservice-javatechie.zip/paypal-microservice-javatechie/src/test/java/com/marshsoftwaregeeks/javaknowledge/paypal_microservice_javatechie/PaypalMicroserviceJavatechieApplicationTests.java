package com.marshsoftwaregeeks.javaknowledge.paypal_microservice_javatechie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaypalMicroserviceJavatechieApplicationTests {

	@Test
	void contextLoads() {
	}

}
